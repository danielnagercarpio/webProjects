 $(document).ready(function() {
   setInterval(reloadData, 60000);

   function reloadData() {
    app.cargaDatos(app.urlManresa,MANRESA);
    app.cargaDatos(app.urlSolsona,SOLSONA);
    app.cargaDatos(app.urlVic,VIC);
    app.cargaDatos(app.urlBalaguer,BALAGUER);
  }
  
 });
// Creamos el objeto app 
var app = {};

// Api key 
app.apikey = "e89876cdc001c833a224ec9d22c3e468";

// latitud i longitud de malaga
const SOLSONA = 'solsona';
const MANRESA = 'manresa';
const VIC = 'vic';
const BALAGUER = 'balaguer';

// url de la app
app.urlManresa = `https://api.openweathermap.org/data/2.5/weather?q=${MANRESA}&appid=${app.apikey}&units=metric`;
app.urlSolsona = `https://api.openweathermap.org/data/2.5/weather?q=${SOLSONA}&appid=${app.apikey}&units=metric`;
app.urlVic = `https://api.openweathermap.org/data/2.5/weather?q=${VIC}&appid=${app.apikey}&units=metric`;
app.urlBalaguer = `https://api.openweathermap.org/data/2.5/weather?q=${BALAGUER}&appid=${app.apikey}&units=metric`;


app.cargaDatos = function(apiurl,city) {
  $.ajax({
    url: apiurl,
    success: function(data) {
      // guardamos en la variable datos dentro del objeto app toda la información en bruto
      app.datos = data;
      app.procesaDatos(city);
    },
    error: function() {
      alert("Ups, no puedo obtener información de la api");
    }
  });
}

app.cargaDatos(app.urlManresa,MANRESA);
app.cargaDatos(app.urlSolsona,SOLSONA);
app.cargaDatos(app.urlVic,VIC);
app.cargaDatos(app.urlBalaguer,BALAGUER);

app.procesaDatos = function(capital) {
  app.condicionNombre = app.datos.weather[0].main;
  app.temperatura = app.datos.main.temp, 10;
  app.icono = app.datos.weather[0].icon;
  app.muestra(capital);
}

app.muestra = function(capital){
    $('#mapaCatalunya').append(`
    <div id="${capital}">
      <div class='weather_temperature'>${capital} <br>${app.temperatura}º</div>
      <img src="http://openweathermap.org/img/wn/${app.icono}@2x.png"></img>
    </div>`);
}
